﻿namespace Operators_Harjo_Ryan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Initializes an integer that multiplies two integers
            int intMult = 5 * 20;
            // Initialized an integer that adds to integers
            int intAdd = 10 + 99;
            // Output the maximum and minimum values between intMult and intAdd
            Console.WriteLine($"The max of {intMult} and {intAdd} is {Math.Max(intMult, intAdd)}. " +
                $"The min of the two is {Math.Min(intMult, intAdd)}.");

            // Compare if intMult is greater than intAdd and store the result in isIntGreater
            bool isIntGreater = intMult > intAdd;
            // Output the result of the comparison
            Console.WriteLine($"{intMult} is greater than {intAdd}, {isIntGreater}.");



            // Initializes a short that multiplies two short
            short shortMult = 5 * 20;
            // Initialized a short that adds to short
            short shortAdd = 10 + 99;
            // Output the maximum and minimum values between shortMult and shortAdd
            Console.WriteLine($"The max of {shortMult} and {shortAdd} is {Math.Max(shortMult, shortAdd)}. " +
                $"The min of the two is {Math.Min(shortMult, shortAdd)}.");

            // Compare if shortMult is greater than shortAdd and store the result in isshortGreater
            bool isshortGreater = shortMult > shortAdd;
            // Output the result of the comparison
            Console.WriteLine($"{shortMult} is greater than {shortAdd}, {isshortGreater}.");



            // Initializes a long that multiplies two long
            long longMult = 5 * 20;
            // Initialized a long that adds to long
            long longAdd = 10 + 99;
            // Output the maximum and minimum values between longMult and longAdd
            Console.WriteLine($"The max of {longMult} and {longAdd} is {Math.Max(longMult, longAdd)}. " +
                $"The min of the two is {Math.Min(longMult, longAdd)}.");

            // Compare if longMult is greater than longAdd and store the result in islongGreater
            bool islongGreater = longMult > longAdd;
            // Output the result of the comparison
            Console.WriteLine($"{longMult} is greater than {longAdd}, {islongGreater}.");



            // Initializes a float that multiplies two floats 
            float floatMult = 5.9f * 20.666f;
            // Initialized a float that adds to float
            float floatAdd = 10.10f + 99.99f;
            // Output the maximum and minimum values between floatMult and floatAdd
            Console.WriteLine($"The max of {floatMult} and {floatAdd} is {Math.Max(floatMult, floatAdd)}. " +
                $"The min of the two is {Math.Min(floatMult, floatAdd)}.");

            // Compare if floatMult is greater than floatAdd and store the result in isfloatGreater
            bool isfloatGreater = floatMult > floatAdd;
            // Output the result of the comparison
            Console.WriteLine($"{floatMult} is greater than {floatAdd}, {isfloatGreater}.");


            // initializes a double that multiplies two double
            double doubleMult = 5.9 * 20.666;
            // Initialized a double that adds to double
            double doubleAdd = 10.10 + 99.99;
            // Output the maximum and minimum values between doubleMult and doubleAdd
            Console.WriteLine($"The max of {doubleMult} and {doubleAdd} is {Math.Max(doubleMult, doubleAdd)}. " +
                $"The min of the two is {Math.Min(doubleMult, doubleAdd)}.");
            // Compare if doubleMult is greater than doubleAdd and store the result in isdoubleGreater
            bool isdoubleGreater = doubleMult > doubleAdd;
            // Output the result of the comparison
            Console.WriteLine($"{doubleMult} is greater than {doubleAdd}, {isdoubleGreater}.");


            // initializes a decimal that multiplies two decimal
            decimal decimalMult = (decimal)(5.9 * 20.666);
            // Initialized a decimal that adds to decimal
            decimal decimalAdd = (decimal)(10.10 + 99.99);
            // Output the maximum and minimum values between decimalMult and decimalAdd
            Console.WriteLine($"The max of {decimalMult} and {decimalAdd} is {Math.Max(decimalMult, decimalAdd)}. " +
               $"The min of the two is {Math.Min(decimalMult, decimalAdd)}.");
            // Compare if decimalMult is greater than decimalAdd and store the result in isdecimalGreater
            bool isdecimalGreater = decimalMult > decimalAdd;
            // Output the result of the comparison
            Console.WriteLine($"{decimalMult} is greater than {decimalAdd}, {isdecimalGreater}.");
        }
    }
}
